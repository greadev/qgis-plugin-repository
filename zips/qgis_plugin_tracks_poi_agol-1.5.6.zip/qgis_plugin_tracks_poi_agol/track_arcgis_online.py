import json
import os
import urllib.parse
import urllib.request
import time
from datetime import datetime, timezone

from qgis.PyQt.QtCore import QVariant, QDateTime, QSettings, QTimeZone, QUrl
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsField,
    QgsFields,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsVectorLayer,
    QgsVectorFileWriter,
    QgsEditorWidgetSetup,
    QgsAction,
)

from .track_arcgis_online_dialog import (
    TrackArcGISOnlineDialog,
    DEFAULT_TRACKS_URL,
    DEFAULT_FIELDMAPS_URL,
    DEFAULT_PORTAL,
)


class TrackArcGISOnlinePlugin:
    SETTINGS_PREFIX = "agol_tracks_poi"
    PLUGIN_NAME = "AGOL Tracks & POI"
    PLUGIN_MENU = "AGOL Tracks & POI"
    PAGE_SIZE = 2000
    TRACKS_DATE_FIELD = "location_timestamp"
    TRACKS_USER_FIELD = "full_name"
    FIELDMAPS_DATE_FIELD = "Fix Time"
    FIELDMAPS_USER_FIELD = "Creator"
    SPAIN_TZ_ID = b"Europe/Madrid"

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.toolbar = None
        self.dialog = None
        self.plugin_dir = os.path.dirname(__file__)
        self.icon_path = os.path.join(self.plugin_dir, "icon.jpg")

    def initGui(self):
        self.action = QAction(QIcon(self.icon_path), self.PLUGIN_NAME, self.iface.mainWindow())
        self.action.setIconText(self.PLUGIN_NAME)
        self.action.setToolTip("AGOL Tracks & POI - Descargar tracks y puntos de ArcGIS Online por rango de fechas")
        self.action.triggered.connect(self.run)

        # Barra propia del plugin para que se muestre con el icono y el nombre.
        self.toolbar = self.iface.addToolBar(self.PLUGIN_NAME)
        self.toolbar.setObjectName("AGOL Tracks & POI")
        self.toolbar.addAction(self.action)

        self.iface.addPluginToMenu(self.PLUGIN_MENU, self.action)

    def unload(self):
        if self.action:
            if self.toolbar:
                self.toolbar.removeAction(self.action)
                self.toolbar.deleteLater()
                self.toolbar = None
            self.iface.removePluginMenu(self.PLUGIN_MENU, self.action)

    def run(self):
        self.dialog = TrackArcGISOnlineDialog(self.iface.mainWindow())
        self.dialog.setWindowIcon(QIcon(self.icon_path))
        self._load_settings_into_dialog()
        self.dialog.save_config_button.clicked.connect(self.save_config)
        self.dialog.load_button.clicked.connect(self.load_tracks)
        self.dialog.fieldmaps_load_button.clicked.connect(self.load_fieldmaps_points)
        self.dialog.show()

    def _settings(self):
        return QSettings()

    def _load_settings_into_dialog(self):
        settings = self._settings()
        dlg = self.dialog
        dlg.url_edit.setText(settings.value(f"{self.SETTINGS_PREFIX}/url", DEFAULT_TRACKS_URL))
        dlg.fieldmaps_url_edit.setText(settings.value(f"{self.SETTINGS_PREFIX}/fieldmaps_url", DEFAULT_FIELDMAPS_URL))
        dlg.portal_edit.setText(settings.value(f"{self.SETTINGS_PREFIX}/portal", DEFAULT_PORTAL))
        dlg.username_edit.setText(settings.value(f"{self.SETTINGS_PREFIX}/username", ""))
        dlg.password_edit.setText(settings.value(f"{self.SETTINGS_PREFIX}/password", ""))
        dlg.save_path_edit.setText(settings.value(f"{self.SETTINGS_PREFIX}/save_path", ""))
        dlg.fieldmaps_save_path_edit.setText(settings.value(f"{self.SETTINGS_PREFIX}/fieldmaps_save_path", ""))
        if hasattr(dlg, "fieldmaps_attachments_path_edit"):
            dlg.fieldmaps_attachments_path_edit.setText(settings.value(f"{self.SETTINGS_PREFIX}/fieldmaps_attachments_path", ""))

    def save_config(self):
        dlg = self.dialog
        tracks_url = dlg.url_edit.text().strip().rstrip("/")
        fieldmaps_url = dlg.fieldmaps_url_edit.text().strip().rstrip("/")
        portal_url = dlg.portal_edit.text().strip().rstrip("/") or DEFAULT_PORTAL
        username = dlg.username_edit.text().strip()
        password = dlg.password_edit.text()

        if not tracks_url:
            QMessageBox.warning(dlg, "Falta URL", "Indica la URL de la capa de tracks de ArcGIS.")
            return
        if not portal_url:
            QMessageBox.warning(dlg, "Falta portal", "Indica el Portal ArcGIS.")
            return

        settings = self._settings()
        settings.setValue(f"{self.SETTINGS_PREFIX}/url", tracks_url)
        settings.setValue(f"{self.SETTINGS_PREFIX}/fieldmaps_url", fieldmaps_url)
        settings.setValue(f"{self.SETTINGS_PREFIX}/portal", portal_url)
        settings.setValue(f"{self.SETTINGS_PREFIX}/username", username)
        settings.setValue(f"{self.SETTINGS_PREFIX}/password", password)
        settings.setValue(f"{self.SETTINGS_PREFIX}/save_path", dlg.save_path_edit.text().strip())
        settings.setValue(f"{self.SETTINGS_PREFIX}/fieldmaps_save_path", dlg.fieldmaps_save_path_edit.text().strip())
        if hasattr(dlg, "fieldmaps_attachments_path_edit"):
            settings.setValue(f"{self.SETTINGS_PREFIX}/fieldmaps_attachments_path", dlg.fieldmaps_attachments_path_edit.text().strip())
        settings.sync()

        QMessageBox.information(dlg, "Configuración guardada", "Configuración guardada correctamente.")

    def load_tracks(self):
        dlg = self.dialog
        # La descarga de Tracks Arcgis usa exclusivamente la URL indicada en
        # Configuración > URL capa tracks. No se usa ninguna URL fija interna
        # salvo como valor inicial si el usuario no ha guardado otra.
        tracks_url = dlg.url_edit.text().strip().rstrip("/")
        self._download_layer(
            title="tracks",
            url=tracks_url,
            date_from=dlg.from_edit.dateTime(),
            date_to=dlg.to_edit.dateTime(),
            save_path=dlg.save_path_edit.text().strip(),
            save_path_setter=dlg.save_path_edit.setText,
            date_field=self.TRACKS_DATE_FIELD,
            user_field=self.TRACKS_USER_FIELD,
            selected_users=dlg.selected_users(),
            user_filter_enabled=dlg.filter_users_checkbox.isChecked(),
            load_button=dlg.load_button,
            log_func=dlg.append_log,
            config_missing_message="Configura la URL en Configuración > URL capa tracks.",
            no_results_message="La consulta no devolvió tracks para ese filtro.",
        )

    def load_fieldmaps_points(self):
        dlg = self.dialog
        self._download_layer(
            title="puntos Field Maps",
            url=dlg.fieldmaps_url_edit.text().strip().rstrip("/"),
            date_from=dlg.fieldmaps_from_edit.dateTime(),
            date_to=dlg.fieldmaps_to_edit.dateTime(),
            save_path=dlg.fieldmaps_save_path_edit.text().strip(),
            save_path_setter=dlg.fieldmaps_save_path_edit.setText,
            date_field=self.FIELDMAPS_DATE_FIELD,
            user_field=self.FIELDMAPS_USER_FIELD,
            selected_users=dlg.selected_fieldmaps_users(),
            user_filter_enabled=dlg.fieldmaps_filter_users_checkbox.isChecked(),
            load_button=dlg.fieldmaps_load_button,
            log_func=dlg.append_fieldmaps_log,
            config_missing_message="Configura la URL de la capa puntos Field Maps.",
            no_results_message="La consulta no devolvió puntos Field Maps para ese filtro.",
            download_attachments=dlg.fieldmaps_download_attachments_checkbox.isChecked(),
            attachments_path=dlg.fieldmaps_attachments_path_edit.text().strip(),
            attachments_title="puntos Field Maps",
        )

    def _download_layer(
        self,
        title,
        url,
        date_from,
        date_to,
        save_path,
        save_path_setter,
        date_field,
        user_field,
        selected_users,
        user_filter_enabled,
        load_button,
        log_func,
        config_missing_message,
        no_results_message,
        download_attachments=False,
        attachments_path="",
        attachments_title=None,
    ):
        dlg = self.dialog
        self._save_current_config_silently()

        portal_url = dlg.portal_edit.text().strip().rstrip("/") or DEFAULT_PORTAL
        username = dlg.username_edit.text().strip()
        password = dlg.password_edit.text()

        if not url:
            dlg.tabs.setCurrentWidget(dlg.config_tab)
            QMessageBox.warning(dlg, "Falta URL", config_missing_message)
            return
        if not username or not password:
            dlg.tabs.setCurrentWidget(dlg.config_tab)
            QMessageBox.warning(dlg, "Faltan credenciales", "Configura usuario y contraseña de ArcGIS Online.")
            return
        if date_from > date_to:
            QMessageBox.warning(dlg, "Fechas incorrectas", "La fecha 'Desde' debe ser anterior a 'Hasta'.")
            return
        if user_filter_enabled and not selected_users:
            QMessageBox.warning(
                dlg,
                "Faltan usuarios",
                "Has activado el filtro por usuarios, pero no has seleccionado ningún usuario.",
            )
            return

        if not save_path:
            QMessageBox.warning(dlg, "Falta ruta", "Indica la ruta donde guardar la capa descargada.")
            return
        save_path = self._normalize_output_path(save_path)
        output_dir = os.path.dirname(save_path) or os.getcwd()
        if not os.path.isdir(output_dir):
            QMessageBox.warning(dlg, "Ruta no válida", f"La carpeta no existe:\n{output_dir}")
            return
        save_path_setter(save_path)

        load_button.setEnabled(False)
        try:
            log_func("Solicitando token a ArcGIS...")
            token = self._generate_arcgis_token(portal_url, username, password)
            log_func("Token obtenido correctamente.")

            if title == "tracks":
                log_func(f"URL de capa tracks usada desde Configuración > URL capa tracks: {url}")
            elif title == "puntos Field Maps":
                log_func(f"URL de capa puntos Field Maps usada desde Configuración > URL capa puntos field maps: {url}")
            else:
                log_func(f"URL de capa usada para {title}: {url}")
            log_func("Consultando metadatos de la capa...")
            metadata = self._request_json(url, {"f": "json", "token": token})
            if "error" in metadata:
                raise RuntimeError(self._format_arcgis_error(metadata["error"]))

            if not metadata.get("fields") and metadata.get("layers"):
                layers = metadata.get("layers") or []
                if not layers:
                    raise RuntimeError("La URL parece ser un servicio FeatureServer, pero no contiene capas.")
                selected_layer = layers[0]
                layer_id = selected_layer.get("id")
                if layer_id is None:
                    raise RuntimeError("No se pudo detectar el id de la capa dentro del FeatureServer.")
                url = url.rstrip("/") + "/" + str(layer_id)
                log_func(
                    "La URL configurada parece ser el servicio FeatureServer. "
                    + "Se usará automáticamente la capa " + str(layer_id) + ": "
                    + str(selected_layer.get("name", ""))
                )
                log_func(f"URL final de capa usada para {title}: {url}")
                metadata = self._request_json(url, {"f": "json", "token": token})
                if "error" in metadata:
                    raise RuntimeError(self._format_arcgis_error(metadata["error"]))

            geometry_type = metadata.get("geometryType", "esriGeometryPoint")
            fields_def = metadata.get("fields", [])
            if not fields_def:
                raise RuntimeError("No se pudieron leer campos en los metadatos. Revisa que la URL configurada sea la URL de una capa FeatureServer, por ejemplo .../FeatureServer/0, y que el usuario tenga permisos sobre esa capa.")

            # La capa que se crea y se carga en QGIS se nombra igual que el archivo de salida.
            # Ej.: C:/datos/tracks_2026.gpkg -> capa "tracks_2026".
            layer_name = self._layer_name_from_save_path(save_path)
            log_func(f"Nombre de capa en QGIS: {layer_name}")

            resolved_date_field = self._resolve_arcgis_field_name(fields_def, date_field)
            resolved_user_field = self._resolve_arcgis_field_name(fields_def, user_field)

            if not resolved_date_field:
                resolved_date_field = date_field
                log_func(
                    f"AVISO: no se encontró el campo o alias '{date_field}' en los metadatos. "
                    "Se intentará consultar igualmente con ese texto."
                )
            elif resolved_date_field != date_field:
                log_func(f"Campo de fecha '{date_field}' resuelto como nombre interno: {resolved_date_field}")

            if selected_users and not resolved_user_field:
                resolved_user_field = user_field
                log_func(
                    f"AVISO: no se encontró el campo o alias '{user_field}' en los metadatos. "
                    "Se intentará consultar igualmente con ese texto."
                )
            elif selected_users and resolved_user_field != user_field:
                log_func(f"Campo de usuarios '{user_field}' resuelto como nombre interno: {resolved_user_field}")

            start_sql = self._qdatetime_to_arcgis_timestamp(date_from)
            end_sql = self._qdatetime_to_arcgis_timestamp(date_to)
            where = (
                f"{resolved_date_field} >= timestamp '{start_sql}' "
                f"AND {resolved_date_field} <= timestamp '{end_sql}'"
            )
            if selected_users:
                users_sql = ", ".join(f"'{self._escape_sql_literal(user)}'" for user in selected_users)
                where = f"({where}) AND {resolved_user_field} IN ({users_sql})"

            params_common = {
                "f": "json",
                "where": where,
                "outFields": "*",
                "returnGeometry": "true",
                "outSR": "4326",
                "token": token,
            }
            log_func(f"Filtro aplicado: {where}")
            if selected_users:
                log_func(f"Filtro de usuarios sobre {user_field}: " + ", ".join(selected_users))
            log_func("Los campos de fecha se cargarán en zona horaria Europe/Madrid.")

            all_features = []
            offset = 0
            while True:
                params = dict(params_common)
                params.update({
                    "resultOffset": str(offset),
                    "resultRecordCount": str(self.PAGE_SIZE),
                })
                log_func(f"Consultando features desde offset {offset}...")
                response = self._request_json(url + "/query", params)
                if "error" in response:
                    raise RuntimeError(self._format_arcgis_error(response["error"]))

                features = response.get("features", [])
                all_features.extend(features)
                log_func(f"Recibidos {len(features)} registros. Total: {len(all_features)}")

                exceeded = bool(response.get("exceededTransferLimit"))
                if len(features) < self.PAGE_SIZE or not exceeded:
                    break
                offset += self.PAGE_SIZE

            if not all_features:
                QMessageBox.information(dlg, "Sin resultados", no_results_message)
                return

            attachment_summary = None
            attachment_links_by_oid = {}
            oid_field_for_attachments = None
            if download_attachments:
                attachment_summary = self._download_feature_attachments(
                    layer_url=url,
                    token=token,
                    metadata=metadata,
                    features=all_features,
                    save_path=save_path,
                    attachments_path=attachments_path,
                    log_func=log_func,
                    title=attachments_title or title,
                )
                attachment_links_by_oid = attachment_summary.get("links_by_oid", {}) or {}
                oid_field_for_attachments = attachment_summary.get("oid_field")

            memory_layer = self._build_memory_layer(
                layer_name,
                geometry_type,
                fields_def,
                all_features,
                extra_string_fields=["adjunto"] if download_attachments else None,
                extra_attrs_by_oid=attachment_links_by_oid if download_attachments else None,
                oid_field=oid_field_for_attachments,
            )
            self._prepare_output_for_write(save_path, log_func)
            self._save_layer_to_path(memory_layer, save_path)
            log_func(f"Archivo guardado: {save_path}")

            saved_layer = self._load_saved_layer(save_path, memory_layer.name())
            if not saved_layer.isValid():
                raise RuntimeError(f"El archivo se guardó, pero QGIS no pudo cargar la capa desde: {save_path}")

            if download_attachments:
                self._configure_attachment_hyperlink(saved_layer, save_path, "adjunto", log_func)

            QgsProject.instance().addMapLayer(saved_layer)
            log_func(f"Capa cargada desde archivo: {saved_layer.name()} ({saved_layer.featureCount()} registros)")

            message = f"Se guardaron y cargaron {saved_layer.featureCount()} registros en:\n{save_path}"
            if attachment_summary:
                message += (
                    f"\n\nAdjuntos descargados: {attachment_summary['downloaded']}"
                    f" de {attachment_summary['features_with_attachments']} registros con adjuntos."
                    f"\nCarpeta adjuntos:\n{attachment_summary['folder']}"
                )
            QMessageBox.information(
                dlg,
                "Descarga completada",
                message,
            )
        except Exception as exc:
            log_func(f"ERROR: {exc}")
            QMessageBox.critical(dlg, f"Error al descargar {title}", str(exc))
        finally:
            load_button.setEnabled(True)

    def _save_current_config_silently(self):
        dlg = self.dialog
        settings = self._settings()
        settings.setValue(f"{self.SETTINGS_PREFIX}/url", dlg.url_edit.text().strip().rstrip("/"))
        settings.setValue(f"{self.SETTINGS_PREFIX}/fieldmaps_url", dlg.fieldmaps_url_edit.text().strip().rstrip("/"))
        settings.setValue(f"{self.SETTINGS_PREFIX}/portal", dlg.portal_edit.text().strip().rstrip("/") or DEFAULT_PORTAL)
        settings.setValue(f"{self.SETTINGS_PREFIX}/username", dlg.username_edit.text().strip())
        settings.setValue(f"{self.SETTINGS_PREFIX}/password", dlg.password_edit.text())
        settings.setValue(f"{self.SETTINGS_PREFIX}/save_path", dlg.save_path_edit.text().strip())
        settings.setValue(f"{self.SETTINGS_PREFIX}/fieldmaps_save_path", dlg.fieldmaps_save_path_edit.text().strip())
        if hasattr(dlg, "fieldmaps_attachments_path_edit"):
            settings.setValue(f"{self.SETTINGS_PREFIX}/fieldmaps_attachments_path", dlg.fieldmaps_attachments_path_edit.text().strip())
        settings.sync()

    def _request_json(self, base_url, params):
        clean_params = {k: v for k, v in params.items() if v is not None and v != ""}
        data = urllib.parse.urlencode(clean_params).encode("utf-8")
        req = urllib.request.Request(
            base_url,
            data=data,
            headers={"User-Agent": "QGIS AGOL Tracks & POI Plugin"},
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            raw = resp.read().decode("utf-8")
        return json.loads(raw)

    def _generate_arcgis_token(self, portal_url, username, password):
        token_url = portal_url.rstrip("/") + "/sharing/rest/generateToken"
        params = {
            "f": "json",
            "username": username,
            "password": password,
            "client": "referer",
            "referer": portal_url.rstrip("/"),
            "expiration": "60",
        }
        response = self._request_json(token_url, params)
        if "error" in response:
            raise RuntimeError(self._format_arcgis_error(response["error"]))
        token = response.get("token")
        if not token:
            raise RuntimeError("ArcGIS no devolvió token. Revisa usuario, contraseña, portal y permisos sobre la capa.")
        return token

    def _build_memory_layer(
        self,
        layer_name,
        geometry_type,
        fields_def,
        features,
        extra_string_fields=None,
        extra_attrs_by_oid=None,
        oid_field=None,
    ):
        qgis_geom = self._qgis_geometry_name(geometry_type)
        layer = QgsVectorLayer(f"{qgis_geom}?crs=EPSG:4326", self._safe_layer_name(layer_name), "memory")
        provider = layer.dataProvider()

        extra_string_fields = extra_string_fields or []
        extra_attrs_by_oid = extra_attrs_by_oid or {}

        qgs_fields = QgsFields()
        field_types_by_name = {}
        existing_names_lower = set()
        for field_def in fields_def:
            name = field_def.get("name")
            if not name:
                continue
            esri_type = field_def.get("type")
            field_types_by_name[name] = esri_type
            existing_names_lower.add(str(name).lower())
            qgs_fields.append(QgsField(name, self._qvariant_type(esri_type)))

        for extra_name in extra_string_fields:
            if extra_name.lower() not in existing_names_lower:
                field_types_by_name[extra_name] = "string"
                qgs_fields.append(QgsField(extra_name, QVariant.String))
                existing_names_lower.add(extra_name.lower())

        provider.addAttributes(qgs_fields)
        layer.updateFields()

        qgs_features = []
        field_names = [f.name() for f in layer.fields()]
        for item in features:
            attrs = item.get("attributes", {}) or {}
            object_id = attrs.get(oid_field) if oid_field else None
            values = []
            for name in field_names:
                if name in extra_string_fields:
                    values.append(extra_attrs_by_oid.get(str(object_id), "") if object_id is not None else "")
                else:
                    values.append(self._convert_attr(attrs.get(name), field_types_by_name.get(name)))
            feat = QgsFeature(layer.fields())
            feat.setAttributes(values)
            geom = self._arcgis_geometry_to_qgs(item.get("geometry"), geometry_type)
            if geom:
                feat.setGeometry(geom)
            qgs_features.append(feat)

        provider.addFeatures(qgs_features)
        layer.updateExtents()
        return layer

    def _arcgis_geometry_to_qgs(self, geom, geometry_type):
        if not geom:
            return None
        if geometry_type == "esriGeometryPoint" or ("x" in geom and "y" in geom):
            return QgsGeometry.fromPointXY(QgsPointXY(float(geom["x"]), float(geom["y"])))
        if geometry_type == "esriGeometryPolyline" or "paths" in geom:
            paths = geom.get("paths") or []
            if not paths:
                return None
            lines = [[QgsPointXY(float(x), float(y)) for x, y, *rest in path] for path in paths]
            if len(lines) == 1:
                return QgsGeometry.fromPolylineXY(lines[0])
            return QgsGeometry.fromMultiPolylineXY(lines)
        if geometry_type == "esriGeometryPolygon" or "rings" in geom:
            rings = geom.get("rings") or []
            if not rings:
                return None
            poly = [[QgsPointXY(float(x), float(y)) for x, y, *rest in ring] for ring in rings]
            return QgsGeometry.fromPolygonXY(poly)
        return None

    def _qgis_geometry_name(self, arcgis_geometry_type):
        if arcgis_geometry_type == "esriGeometryPolyline":
            return "LineString"
        if arcgis_geometry_type == "esriGeometryPolygon":
            return "Polygon"
        return "Point"

    def _qvariant_type(self, esri_type):
        if esri_type in ("esriFieldTypeInteger", "esriFieldTypeSmallInteger", "esriFieldTypeOID"):
            return QVariant.Int
        if esri_type in ("esriFieldTypeDouble", "esriFieldTypeSingle"):
            return QVariant.Double
        if esri_type == "esriFieldTypeDate":
            return QVariant.DateTime
        return QVariant.String

    def _convert_attr(self, value, esri_type=None):
        if value is None:
            return None
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False)
        if esri_type == "esriFieldTypeDate" and isinstance(value, int):
            try:
                return QDateTime.fromMSecsSinceEpoch(value, QTimeZone(self.SPAIN_TZ_ID))
            except Exception:
                return datetime.fromtimestamp(value / 1000, tz=timezone.utc).isoformat()
        return value

    def _qdatetime_to_arcgis_timestamp(self, qdt):
        # La hora introducida por el usuario se consulta contra ArcGIS en UTC.
        # El resultado se convierte después a Europe/Madrid al cargar la capa.
        return qdt.toUTC().toString("yyyy-MM-dd HH:mm:ss")

    def _layer_name_from_save_path(self, path):
        base_name = os.path.basename(str(path).strip())
        stem, _ext = os.path.splitext(base_name)
        return self._safe_layer_name(stem or base_name or "capa")

    def _normalize_output_path(self, path):
        lower_path = path.lower()
        if lower_path.endswith((".gpkg", ".geojson", ".json", ".shp")):
            return path
        return path + ".gpkg"

    def _driver_from_path(self, path):
        lower_path = path.lower()
        if lower_path.endswith((".geojson", ".json")):
            return "GeoJSON"
        if lower_path.endswith(".shp"):
            return "ESRI Shapefile"
        return "GPKG"


    def _prepare_output_for_write(self, path, log_func=None):
        """Libera y elimina archivos existentes para evitar el error OGR 'already exists'."""
        abs_path = os.path.abspath(path)
        norm_abs = os.path.normcase(abs_path)

        # Si la capa ya estaba cargada en QGIS, se elimina del proyecto para soltar el bloqueo del archivo.
        layers_to_remove = []
        for layer_id, layer in QgsProject.instance().mapLayers().items():
            try:
                source_path = layer.source().split("|")[0]
                if os.path.normcase(os.path.abspath(source_path)) == norm_abs:
                    layers_to_remove.append(layer_id)
            except Exception:
                pass
        if layers_to_remove:
            QgsProject.instance().removeMapLayers(layers_to_remove)
            if log_func:
                log_func(f"Se quitó del proyecto la capa existente para poder sobrescribir: {path}")

        driver = self._driver_from_path(path)
        files_to_delete = [path]
        if driver == "ESRI Shapefile":
            base, _ext = os.path.splitext(path)
            files_to_delete = [
                base + ext for ext in (
                    ".shp", ".shx", ".dbf", ".prj", ".cpg", ".qpj", ".sbn", ".sbx", ".shp.xml"
                )
            ]

        for file_path in files_to_delete:
            if not os.path.exists(file_path):
                continue
            last_error = None
            for _ in range(5):
                try:
                    os.remove(file_path)
                    if log_func:
                        log_func(f"Archivo existente eliminado para sobrescribir: {file_path}")
                    last_error = None
                    break
                except Exception as exc:
                    last_error = exc
                    time.sleep(0.2)
            if last_error is not None:
                raise RuntimeError(
                    "No se pudo sobrescribir el archivo existente. "
                    "Cierra cualquier capa, tabla o programa que lo tenga abierto y vuelve a intentarlo:\n"
                    f"{file_path}\n\nDetalle: {last_error}"
                )

    def _download_feature_attachments(self, layer_url, token, metadata, features, save_path, attachments_path, log_func, title):
        oid_field = self._object_id_field(metadata)
        if not oid_field:
            raise RuntimeError(
                "No se pudo detectar el campo ObjectID de la capa; no es posible descargar adjuntos."
            )

        base_name = os.path.splitext(os.path.basename(save_path))[0]
        layer_dir = os.path.dirname(os.path.abspath(save_path)) or os.getcwd()

        # Si el usuario indica una carpeta, se usa esa. Si no, se crea una junto a la capa.
        if attachments_path:
            attachments_folder = os.path.abspath(attachments_path)
        else:
            attachments_folder = os.path.join(layer_dir, f"{base_name}_adjuntos")
        os.makedirs(attachments_folder, exist_ok=True)

        log_func(f"Descargando adjuntos de {title} directamente en: {attachments_folder}")
        features_with_attachments = 0
        downloaded = 0
        links_by_oid = {}

        for index, item in enumerate(features, start=1):
            attrs = item.get("attributes", {}) or {}
            object_id = attrs.get(oid_field)
            if object_id is None:
                continue

            object_id_text = str(object_id)
            safe_object_id = self._safe_filename(object_id_text)

            log_func(f"Consultando adjuntos del registro {index}/{len(features)}. ObjectID={object_id}")
            attachments_info = self._request_json(
                layer_url.rstrip("/") + f"/{object_id}/attachments",
                {"f": "json", "token": token},
            )
            if "error" in attachments_info:
                raise RuntimeError(self._format_arcgis_error(attachments_info["error"]))

            attachments = attachments_info.get("attachmentInfos", []) or []
            if not attachments:
                continue

            features_with_attachments += 1
            relative_links = []

            for attachment_index, attachment in enumerate(attachments, start=1):
                attachment_id = attachment.get("id")
                raw_name = attachment.get("name") or f"adjunto_{attachment_id}"
                _stem, ext = os.path.splitext(self._safe_filename(raw_name))
                if not ext:
                    content_type = str(attachment.get("contentType") or "").lower()
                    ext = self._extension_from_content_type(content_type)

                # Nombre del adjunto: ObjectID_ + valor del campo ObjectID.
                # Si hay varios adjuntos para el mismo registro: ObjectID_123_1.jpg, ObjectID_123_2.jpg, etc.
                if len(attachments) == 1:
                    filename = f"ObjectID_{safe_object_id}{ext}"
                else:
                    filename = f"ObjectID_{safe_object_id}_{attachment_index}{ext}"

                output_path = os.path.join(attachments_folder, filename)
                binary = self._request_binary(
                    layer_url.rstrip("/") + f"/{object_id}/attachments/{attachment_id}",
                    {"token": token},
                )
                with open(output_path, "wb") as fh:
                    fh.write(binary)

                downloaded += 1
                # Guardamos una ruta completa en formato URL local file:///.
                # Esto permite que QGIS lo trate directamente como hiperenlace clicable.
                absolute_link = QUrl.fromLocalFile(os.path.abspath(output_path)).toString()
                relative_links.append(absolute_link)
                log_func(f"Adjunto descargado: {output_path}")

            if relative_links:
                # El campo adjunto debe ser un enlace clicable, así que guardamos un solo archivo por campo.
                # Si un registro tiene varios adjuntos, se conserva como enlace principal el primero descargado.
                links_by_oid[object_id_text] = relative_links[0]

        log_func(
            f"Descarga de adjuntos finalizada. Registros con adjuntos: {features_with_attachments}. "
            f"Archivos descargados: {downloaded}."
        )
        return {
            "folder": attachments_folder,
            "features_with_attachments": features_with_attachments,
            "downloaded": downloaded,
            "links_by_oid": links_by_oid,
            "oid_field": oid_field,
        }

    def _extension_from_content_type(self, content_type):
        mapping = {
            "image/jpeg": ".jpg",
            "image/jpg": ".jpg",
            "image/png": ".png",
            "image/gif": ".gif",
            "application/pdf": ".pdf",
            "text/plain": ".txt",
            "application/msword": ".doc",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
            "application/vnd.ms-excel": ".xls",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
        }
        return mapping.get(content_type, "")

    def _request_binary(self, base_url, params):
        clean_params = {k: v for k, v in params.items() if v is not None and v != ""}
        query = urllib.parse.urlencode(clean_params)
        url = base_url + ("?" + query if query else "")
        req = urllib.request.Request(url, headers={"User-Agent": "QGIS AGOL Tracks & POI Plugin"})
        with urllib.request.urlopen(req, timeout=120) as resp:
            return resp.read()

    def _object_id_field(self, metadata):
        oid = metadata.get("objectIdField") or metadata.get("objectIdFieldName")
        if oid:
            return oid
        for field in metadata.get("fields", []) or []:
            if field.get("type") == "esriFieldTypeOID":
                return field.get("name")
        return None

    def _safe_filename(self, name):
        clean = "".join(ch if ch.isalnum() or ch in " ._-()[]" else "_" for ch in str(name))
        clean = clean.strip().strip(".")
        return clean or "adjunto"

    def _save_layer_to_path(self, layer, path):
        driver = self._driver_from_path(path)
        try:
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = driver
            options.fileEncoding = "UTF-8"
            if hasattr(options, "actionOnExistingFile"):
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
            if driver == "GPKG":
                options.layerName = layer.name()
            result = QgsVectorFileWriter.writeAsVectorFormatV3(
                layer,
                path,
                QgsProject.instance().transformContext(),
                options,
            )
            error_code = result[0]
            error_message = result[1] if len(result) > 1 else ""
        except AttributeError:
            result = QgsVectorFileWriter.writeAsVectorFormat(
                layer,
                path,
                "UTF-8",
                layer.crs(),
                driver,
            )
            error_code = result[0]
            error_message = result[1] if len(result) > 1 else ""

        if error_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(f"No se pudo guardar la capa: {error_message}")

    def _load_saved_layer(self, path, layer_name):
        driver = self._driver_from_path(path)
        if driver == "GPKG":
            source = f"{path}|layername={layer_name}"
        else:
            source = path
        layer = QgsVectorLayer(source, layer_name, "ogr")
        layer.setName(layer_name)
        return layer


    def _configure_attachment_hyperlink(self, layer, save_path, field_name="adjunto", log_func=None):
        """Configura el campo adjunto como recurso externo clicable usando ruta completa file:/// ."""
        field_index = layer.fields().indexFromName(field_name)
        if field_index < 0:
            return

        layer_dir = os.path.dirname(os.path.abspath(save_path))

        # QGIS abre mejor los documentos desde la tabla/formulario cuando el campo usa
        # el widget ExternalResource con FileWidget=True y UseLink=True. El valor del
        # campo ahora es una URL local completa file:///... para que sea clicable.
        config = {
            "DocumentViewer": 0,
            "DocumentViewerHeight": 0,
            "DocumentViewerWidth": 0,
            "FileWidget": True,
            "FileWidgetButton": False,
            "FullUrl": True,
            "RelativeStorage": 0,
            "StorageMode": 0,
            "UseLink": True,
            "DefaultRoot": "",
        }
        try:
            layer.setEditorWidgetSetup(field_index, QgsEditorWidgetSetup("ExternalResource", config))
            layer.setFieldAlias(field_index, "Adjunto")
            layer.setCustomProperty("agol_tracks_poi/attachment_base_dir", layer_dir)
            layer.triggerRepaint()
        except Exception as exc:
            if log_func:
                log_func(f"AVISO: no se pudo configurar el widget ExternalResource del campo 'adjunto': {exc}")

        open_action_code = """
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import QMessageBox
import os

source = r\"\"\"[% @layer_source %]\"\"\"
rel_value = r\"\"\"[% "adjunto" %]\"\"\"
source = source.split('|')[0]
base_dir = os.path.dirname(source)

if not rel_value.strip():
    QMessageBox.information(None, "Sin adjunto", "Este registro no tiene adjunto asociado.")
else:
    path = rel_value.strip()
    if path.lower().startswith('file:///'):
        QDesktopServices.openUrl(QUrl(path))
    else:
        if not os.path.isabs(path):
            path = os.path.normpath(os.path.join(base_dir, path))
        if os.path.exists(path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        else:
            QMessageBox.warning(None, "Adjunto no encontrado", "No se encontró:\\n" + path)
""".strip()

        try:
            existing = [a.name() for a in layer.actions().actions()]
            if "Abrir adjunto" not in existing:
                layer.actions().addAction(QgsAction.GenericPython, "Abrir adjunto", open_action_code)
            layer.setCustomProperty("agol_tracks_poi/attachment_action", "Abrir adjunto")
            self._persist_attachment_style(layer, save_path, log_func)
            if log_func:
                log_func(
                    "Campo 'adjunto' configurado como enlace clicable de recurso externo. "
                    "El valor guardado es una ruta completa file:/// al documento adjunto."
                )
        except Exception as exc:
            if log_func:
                log_func(f"AVISO: no se pudo crear la acción 'Abrir adjunto': {exc}")

    def _persist_attachment_style(self, layer, save_path, log_func=None):
        """Guarda la configuración del enlace para que se conserve al reabrir la capa."""
        try:
            qml_path = os.path.splitext(save_path)[0] + ".qml"
            layer.saveNamedStyle(qml_path)
            if log_func:
                log_func(f"Estilo QGIS guardado junto a la capa: {qml_path}")
        except Exception as exc:
            if log_func:
                log_func(f"AVISO: no se pudo guardar el estilo .qml del enlace: {exc}")

        try:
            layer.saveStyleToDatabase(
                "AGOL Tracks & POI - adjuntos",
                "Campo adjunto como enlace completo file:/// y acción para abrir documentos adjuntos",
                True,
                "",
            )
            if log_func:
                log_func("Estilo guardado como predeterminado dentro de la fuente de datos, si el formato lo soporta.")
        except Exception:
            pass

    def _safe_layer_name(self, name):
        clean = "".join(ch if ch.isalnum() or ch in " _-" else "_" for ch in str(name))
        return clean or "arcgis_online_layer"

    def _escape_sql_literal(self, value):
        return str(value).replace("'", "''")

    def _resolve_arcgis_field_name(self, fields_def, requested):
        """Devuelve el nombre interno del campo a partir del nombre o alias visible de ArcGIS.

        ArcGIS puede exponer un alias como "Fix Time" aunque el nombre real del
        campo sea distinto. También se normalizan espacios, guiones y guiones bajos
        para cubrir casos como Fix_Time / FixTime / Fix Time.
        """
        if not requested:
            return None

        def norm(value):
            return "".join(ch for ch in str(value or "").strip().lower() if ch.isalnum())

        requested_exact = str(requested).strip().lower()
        requested_norm = norm(requested)
        for field in fields_def or []:
            name = str(field.get("name") or "").strip()
            alias = str(field.get("alias") or "").strip()
            if name and name.lower() == requested_exact:
                return name
            if alias and alias.lower() == requested_exact:
                return name
            if name and norm(name) == requested_norm:
                return name
            if alias and norm(alias) == requested_norm:
                return name
        return None

    def _format_arcgis_error(self, error):
        code = error.get("code", "")
        message = error.get("message", "Error ArcGIS")
        details = "; ".join(error.get("details", []) or [])
        if details:
            return f"ArcGIS error {code}: {message}. {details}"
        return f"ArcGIS error {code}: {message}"
