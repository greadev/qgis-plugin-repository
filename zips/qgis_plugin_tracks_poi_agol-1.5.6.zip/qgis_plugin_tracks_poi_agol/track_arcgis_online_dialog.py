from qgis.PyQt.QtCore import Qt, QDateTime
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QFormLayout,
    QLineEdit,
    QDateTimeEdit,
    QPushButton,
    QDialogButtonBox,
    QLabel,
    QPlainTextEdit,
    QWidget,
    QTabWidget,
    QHBoxLayout,
    QFileDialog,
    QCheckBox,
    QGridLayout,
    QGroupBox,
)

DEFAULT_TRACKS_URL = "https://locationservices7.arcgis.com/ckVM1LQ46q7XcVq1/arcgis/rest/services/cfb632e0f7da409cbe6d05ed9bfcdf0b_Track_View/FeatureServer/0"
DEFAULT_FIELDMAPS_URL = "https://services7.arcgis.com/ckVM1LQ46q7XcVq1/arcgis/rest/services/Puntos_interes_zonas_busqueda_BLI/FeatureServer/0"
DEFAULT_PORTAL = "https://www.arcgis.com"


class TrackArcGISOnlineDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AGOL Tracks & POI")
        self.resize(820, 620)

        main_layout = QVBoxLayout(self)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        self.tracks_tab = QWidget()
        self.fieldmaps_tab = QWidget()
        self.config_tab = QWidget()
        self.tabs.addTab(self.tracks_tab, "Tracks Arcgis")
        self.tabs.addTab(self.fieldmaps_tab, "Puntos Field Maps")
        self.tabs.addTab(self.config_tab, "Configuración")

        self._build_tracks_tab()
        self._build_fieldmaps_tab()
        self._build_config_tab()

        self.buttons = QDialogButtonBox(Qt.Horizontal)
        self.close_button = QPushButton("Cerrar")
        self.buttons.addButton(self.close_button, QDialogButtonBox.RejectRole)
        main_layout.addWidget(self.buttons)

        self.close_button.clicked.connect(self.reject)

    def _build_config_tab(self):
        layout = QVBoxLayout(self.config_tab)

        intro = QLabel(
            "Configura las capas de ArcGIS y las credenciales. Estos datos se usarán para descargar tracks y puntos Field Maps."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        form = QFormLayout()

        self.url_edit = QLineEdit(DEFAULT_TRACKS_URL)
        self.url_edit.setMinimumWidth(620)
        self.url_edit.setPlaceholderText("URL de la capa tracks FeatureServer/0")
        form.addRow("URL capa tracks:", self.url_edit)

        self.fieldmaps_url_edit = QLineEdit(DEFAULT_FIELDMAPS_URL)
        self.fieldmaps_url_edit.setMinimumWidth(620)
        self.fieldmaps_url_edit.setPlaceholderText("URL de la capa puntos Field Maps FeatureServer/0")
        form.addRow("URL capa puntos field maps:", self.fieldmaps_url_edit)

        self.portal_edit = QLineEdit(DEFAULT_PORTAL)
        self.portal_edit.setPlaceholderText("Portal ArcGIS. Ej.: https://www.arcgis.com")
        form.addRow("Portal ArcGIS:", self.portal_edit)

        self.username_edit = QLineEdit()
        self.username_edit.setPlaceholderText("Usuario de ArcGIS Online")
        form.addRow("Usuario:", self.username_edit)

        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText("Contraseña de ArcGIS Online")
        form.addRow("Contraseña:", self.password_edit)

        layout.addLayout(form)

        row = QHBoxLayout()
        self.save_config_button = QPushButton("Guardar configuración")
        row.addStretch(1)
        row.addWidget(self.save_config_button)
        layout.addLayout(row)
        layout.addStretch(1)

    def _build_tracks_tab(self):
        layout = QVBoxLayout(self.tracks_tab)

        intro = QLabel(
            "Descarga los tracks de la URL indicada en Configuración. "
            "El rango se aplica siempre al campo location_timestamp."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        form = QFormLayout()
        now = QDateTime.currentDateTime()

        self.from_edit = QDateTimeEdit(now.addDays(-1))
        self.from_edit.setCalendarPopup(True)
        self.from_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        form.addRow("Desde:", self.from_edit)

        self.to_edit = QDateTimeEdit(now)
        self.to_edit.setCalendarPopup(True)
        self.to_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        form.addRow("Hasta:", self.to_edit)

        save_row = QHBoxLayout()
        self.save_path_edit = QLineEdit()
        self.save_path_edit.setPlaceholderText("Ruta donde se guardará la capa. Ej.: C:/datos/tracks.gpkg")
        self.browse_save_path_button = QPushButton("Buscar...")
        save_row.addWidget(self.save_path_edit, 1)
        save_row.addWidget(self.browse_save_path_button)
        form.addRow("Guardar capa en:", save_row)

        layout.addLayout(form)

        self.filter_users_checkbox = QCheckBox("Filtrar por usuarios USER L sobre el campo full_name")
        layout.addWidget(self.filter_users_checkbox)

        self.users_group = QGroupBox("Usuarios USER L")
        users_layout = QGridLayout(self.users_group)
        self.user_checkboxes = []
        for idx in range(1, 13):
            checkbox = QCheckBox(f"USER L{idx}")
            checkbox.setEnabled(False)
            self.user_checkboxes.append(checkbox)
            row = (idx - 1) // 4
            col = (idx - 1) % 4
            users_layout.addWidget(checkbox, row, col)
        layout.addWidget(self.users_group)

        self.filter_users_checkbox.toggled.connect(self._toggle_track_user_checkboxes)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(500)
        self.log.setPlaceholderText("Mensajes de descarga...")
        layout.addWidget(self.log)

        row = QHBoxLayout()
        self.load_button = QPushButton("Descargar tracks")
        row.addStretch(1)
        row.addWidget(self.load_button)
        layout.addLayout(row)

        self.browse_save_path_button.clicked.connect(self.choose_save_path)

    def _build_fieldmaps_tab(self):
        layout = QVBoxLayout(self.fieldmaps_tab)

        intro = QLabel(
            "Descarga los puntos Field Maps de la URL indicada en Configuración. "
            "El rango se aplica siempre al campo Fix Time."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        form = QFormLayout()
        now = QDateTime.currentDateTime()

        self.fieldmaps_from_edit = QDateTimeEdit(now.addDays(-1))
        self.fieldmaps_from_edit.setCalendarPopup(True)
        self.fieldmaps_from_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        form.addRow("Desde:", self.fieldmaps_from_edit)

        self.fieldmaps_to_edit = QDateTimeEdit(now)
        self.fieldmaps_to_edit.setCalendarPopup(True)
        self.fieldmaps_to_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        form.addRow("Hasta:", self.fieldmaps_to_edit)

        save_row = QHBoxLayout()
        self.fieldmaps_save_path_edit = QLineEdit()
        self.fieldmaps_save_path_edit.setPlaceholderText("Ruta donde se guardará la capa. Ej.: C:/datos/puntos_fieldmaps.gpkg")
        self.fieldmaps_browse_save_path_button = QPushButton("Buscar...")
        save_row.addWidget(self.fieldmaps_save_path_edit, 1)
        save_row.addWidget(self.fieldmaps_browse_save_path_button)
        form.addRow("Guardar capa en:", save_row)

        attachments_row = QHBoxLayout()
        self.fieldmaps_attachments_path_edit = QLineEdit()
        self.fieldmaps_attachments_path_edit.setPlaceholderText(
            "Carpeta donde se guardarán los adjuntos. Si se deja vacío, se creará junto a la capa."
        )
        self.fieldmaps_browse_attachments_path_button = QPushButton("Buscar...")
        attachments_row.addWidget(self.fieldmaps_attachments_path_edit, 1)
        attachments_row.addWidget(self.fieldmaps_browse_attachments_path_button)
        form.addRow("Guardar adjuntos en:", attachments_row)

        layout.addLayout(form)

        self.fieldmaps_download_attachments_checkbox = QCheckBox("Descargar documentos adjuntos de cada registro")
        self.fieldmaps_download_attachments_checkbox.setChecked(True)
        layout.addWidget(self.fieldmaps_download_attachments_checkbox)

        self.fieldmaps_filter_users_checkbox = QCheckBox("Filtrar por usuarios USER_L sobre el campo Creator")
        layout.addWidget(self.fieldmaps_filter_users_checkbox)

        self.fieldmaps_users_group = QGroupBox("Usuarios USER_L")
        users_layout = QGridLayout(self.fieldmaps_users_group)
        self.fieldmaps_user_checkboxes = []
        for idx in range(1, 13):
            checkbox = QCheckBox(f"USER_L{idx}")
            checkbox.setEnabled(False)
            self.fieldmaps_user_checkboxes.append(checkbox)
            row = (idx - 1) // 4
            col = (idx - 1) % 4
            users_layout.addWidget(checkbox, row, col)
        layout.addWidget(self.fieldmaps_users_group)

        self.fieldmaps_filter_users_checkbox.toggled.connect(self._toggle_fieldmaps_user_checkboxes)

        self.fieldmaps_log = QPlainTextEdit()
        self.fieldmaps_log.setReadOnly(True)
        self.fieldmaps_log.setMaximumBlockCount(500)
        self.fieldmaps_log.setPlaceholderText("Mensajes de descarga...")
        layout.addWidget(self.fieldmaps_log)

        row = QHBoxLayout()
        self.fieldmaps_load_button = QPushButton("Descargar puntos Field Maps")
        row.addStretch(1)
        row.addWidget(self.fieldmaps_load_button)
        layout.addLayout(row)

        self.fieldmaps_browse_save_path_button.clicked.connect(self.choose_fieldmaps_save_path)
        self.fieldmaps_browse_attachments_path_button.clicked.connect(self.choose_fieldmaps_attachments_path)

    def _toggle_track_user_checkboxes(self, enabled):
        for checkbox in self.user_checkboxes:
            checkbox.setEnabled(enabled)

    def _toggle_fieldmaps_user_checkboxes(self, enabled):
        for checkbox in self.fieldmaps_user_checkboxes:
            checkbox.setEnabled(enabled)

    def selected_users(self):
        if not self.filter_users_checkbox.isChecked():
            return []
        return [checkbox.text() for checkbox in self.user_checkboxes if checkbox.isChecked()]

    def selected_fieldmaps_users(self):
        if not self.fieldmaps_filter_users_checkbox.isChecked():
            return []
        return [checkbox.text() for checkbox in self.fieldmaps_user_checkboxes if checkbox.isChecked()]

    def choose_save_path(self):
        self._choose_output_path(self.save_path_edit, "tracks_arcgis_online.gpkg")

    def choose_fieldmaps_save_path(self):
        self._choose_output_path(self.fieldmaps_save_path_edit, "puntos_fieldmaps.gpkg")

    def choose_fieldmaps_attachments_path(self):
        start_dir = self.fieldmaps_attachments_path_edit.text().strip()
        if not start_dir and self.fieldmaps_save_path_edit.text().strip():
            import os
            start_dir = os.path.dirname(self.fieldmaps_save_path_edit.text().strip())
        path = QFileDialog.getExistingDirectory(
            self,
            "Carpeta para guardar los adjuntos",
            start_dir or "",
        )
        if path:
            self.fieldmaps_attachments_path_edit.setText(path)

    def _choose_output_path(self, line_edit, default_name):
        path, selected_filter = QFileDialog.getSaveFileName(
            self,
            "Ruta para guardar la capa",
            line_edit.text().strip() or default_name,
            "GeoPackage (*.gpkg);;GeoJSON (*.geojson);;Shapefile (*.shp)",
        )
        if not path:
            return
        lower_path = path.lower()
        if selected_filter.startswith("GeoJSON") and not (lower_path.endswith(".geojson") or lower_path.endswith(".json")):
            path += ".geojson"
        elif selected_filter.startswith("Shapefile") and not lower_path.endswith(".shp"):
            path += ".shp"
        elif selected_filter.startswith("GeoPackage") and not lower_path.endswith(".gpkg"):
            path += ".gpkg"
        line_edit.setText(path)

    def append_log(self, message):
        self.log.appendPlainText(str(message))

    def append_fieldmaps_log(self, message):
        self.fieldmaps_log.appendPlainText(str(message))
