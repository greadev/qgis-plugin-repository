# AGOL Tracks & POI

Plugin QGIS 3 para descargar capas privadas de ArcGIS Online usando usuario y contraseña.

## Pestañas

### Tracks Arcgis

Descarga tracks filtrando por rango de fecha y hora sobre el campo `location_timestamp`.

Permite filtrar opcionalmente por usuarios `USER L1` a `USER L12` sobre el campo `full_name`.

### Puntos Field Maps

Descarga puntos Field Maps filtrando por rango de fecha y hora sobre el campo `Fix Time`.

Permite filtrar opcionalmente por usuarios `USER_L1` a `USER_L12` sobre el campo `Creator`.

### Configuración

Permite guardar:

- URL capa tracks
- URL capa puntos field maps
- Portal ArcGIS
- Usuario
- Contraseña

La contraseña se guarda mediante `QSettings` de QGIS. En muchos sistemas no equivale a cifrado real.

## Guardado

Cada descarga se guarda directamente en la ruta indicada y después se carga en QGIS desde el archivo guardado.

Formatos soportados por extensión:

- `.gpkg`
- `.geojson`
- `.json`
- `.shp`

Los campos de fecha de ArcGIS se convierten a zona horaria `Europe/Madrid`.


## Versión 1.4.8

- Añade campo para elegir la carpeta donde guardar adjuntos de Puntos Field Maps.
- El campo `adjunto` guarda rutas relativas desde la ubicación de la capa hacia la carpeta de adjuntos.


## Versión 1.4.9

- Los adjuntos de Puntos Field Maps se nombran como `ObjectID_<valor>.<ext>`.
- El campo `adjunto` mantiene una ruta relativa a la capa.
- Se configura el campo como recurso externo y se añade la acción `Abrir adjunto`, que resuelve la ruta usando la ubicación actual de la capa.
- Se guarda un estilo `.qml` junto a la capa y, si el formato lo permite, un estilo predeterminado en la fuente de datos.

Versión 1.5.0: el campo adjunto se configura como ExternalResource clicable y conserva rutas relativas desde la ubicación de la capa. Para que siga funcionando al mover archivos, mueve el archivo de capa y la carpeta de adjuntos manteniendo la misma relación de carpetas.


## Versión 1.5.1

El campo `adjunto` guarda una ruta completa en formato `file:///...` para que QGIS pueda abrir el archivo directamente como hiperenlace desde la tabla o el formulario de atributos.


## Versión 1.5.2

- La pestaña Tracks Arcgis descarga siempre desde Configuración > URL capa tracks.
- El log muestra explícitamente la URL usada para tracks.


Nombre interno del plugin: `agol_tracks_poi`.


## Versión: 1.5.5

- Nombre de la capa igual al archivo guardado.

## Versión: 1.5.6

- Se realiza corrección en los hiperenlaces de los adjunto para solucionar el problema cuando la ruta tiene espacios en blanco.


