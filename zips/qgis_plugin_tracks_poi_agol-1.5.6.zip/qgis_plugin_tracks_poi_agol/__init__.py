def classFactory(iface):
    from .track_arcgis_online import TrackArcGISOnlinePlugin
    return TrackArcGISOnlinePlugin(iface)
